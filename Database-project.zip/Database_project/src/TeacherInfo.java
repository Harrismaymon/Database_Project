
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class TeacherInfo extends javax.swing.JFrame {

    public TeacherInfo() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        IDLabel = new javax.swing.JLabel();
        namelabel = new javax.swing.JLabel();
        EmailLabel = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        maleRadioBtn = new javax.swing.JRadioButton();
        FemalerdioBtn = new javax.swing.JRadioButton();
        ContactTxtFild = new javax.swing.JTextField();
        ContactLable = new javax.swing.JLabel();
        AdressTxtFild = new javax.swing.JTextField();
        AdressLabel = new javax.swing.JLabel();
        NameTxtFild = new javax.swing.JTextField();
        EmailTxtFild = new javax.swing.JTextField();
        IDTxtFild = new javax.swing.JTextField();
        salaryTxtFild = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        ComboBox = new javax.swing.JComboBox<>();
        Cancel = new javax.swing.JButton();
        ClearBtn = new javax.swing.JButton();
        SaveBtn = new javax.swing.JButton();
        Cancel1 = new javax.swing.JButton();

        jLabel6.setText("jLabel6");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 102, 255));

        jLabel1.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText(" Teachers Information");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setForeground(new java.awt.Color(204, 204, 204));

        IDLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        IDLabel.setText("ID");
        IDLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        namelabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        namelabel.setText("Name");
        namelabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        EmailLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        EmailLabel.setText("Email");
        EmailLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("Gender");
        jLabel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        maleRadioBtn.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        maleRadioBtn.setText("Male");
        maleRadioBtn.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        maleRadioBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maleRadioBtnActionPerformed(evt);
            }
        });

        FemalerdioBtn.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        FemalerdioBtn.setText("Female");
        FemalerdioBtn.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        FemalerdioBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FemalerdioBtnActionPerformed(evt);
            }
        });

        ContactTxtFild.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ContactTxtFild.setForeground(new java.awt.Color(1, 1, 1));
        ContactTxtFild.setAlignmentX(1.0F);
        ContactTxtFild.setAlignmentY(1.0F);
        ContactTxtFild.setAutoscrolls(false);
        ContactTxtFild.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        ContactLable.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        ContactLable.setText("Contact");
        ContactLable.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        AdressTxtFild.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        AdressTxtFild.setForeground(new java.awt.Color(1, 1, 1));
        AdressTxtFild.setAlignmentX(1.0F);
        AdressTxtFild.setAlignmentY(1.0F);
        AdressTxtFild.setAutoscrolls(false);
        AdressTxtFild.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        AdressLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        AdressLabel.setText("Adress");
        AdressLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        NameTxtFild.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        NameTxtFild.setForeground(new java.awt.Color(1, 1, 1));
        NameTxtFild.setAlignmentX(1.0F);
        NameTxtFild.setAlignmentY(1.0F);
        NameTxtFild.setAutoscrolls(false);
        NameTxtFild.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        NameTxtFild.setMargin(new java.awt.Insets(2, 4, 2, 2));

        EmailTxtFild.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        EmailTxtFild.setForeground(new java.awt.Color(1, 1, 1));
        EmailTxtFild.setAlignmentX(1.0F);
        EmailTxtFild.setAlignmentY(1.0F);
        EmailTxtFild.setAutoscrolls(false);
        EmailTxtFild.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        IDTxtFild.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        IDTxtFild.setForeground(new java.awt.Color(1, 1, 1));
        IDTxtFild.setAlignmentX(1.0F);
        IDTxtFild.setAlignmentY(1.0F);
        IDTxtFild.setAutoscrolls(false);
        IDTxtFild.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Salary");

        ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Section", "A", "B" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(IDLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(IDTxtFild))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(namelabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(EmailLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE))
                        .addGap(16, 16, 16)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(EmailTxtFild)
                            .addComponent(NameTxtFild)
                            .addComponent(ComboBox, 0, 172, Short.MAX_VALUE))))
                .addGap(65, 65, 65)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(AdressLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(AdressTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(ContactLable, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(ContactTxtFild)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salaryTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(maleRadioBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(FemalerdioBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(123, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ContactTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ContactLable, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(IDLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(IDTxtFild)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(namelabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NameTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(AdressLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(AdressTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmailLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(maleRadioBtn)
                    .addComponent(FemalerdioBtn)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EmailTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(salaryTxtFild, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ComboBox))
                .addContainerGap(57, Short.MAX_VALUE))
        );

        Cancel.setText("Cancel");
        Cancel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 255)));
        Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelActionPerformed(evt);
            }
        });

        ClearBtn.setText("Clear");
        ClearBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 255)));
        ClearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearBtnActionPerformed(evt);
            }
        });

        SaveBtn.setText("Save");
        SaveBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 255)));
        SaveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBtnActionPerformed(evt);
            }
        });

        Cancel1.setText("Back");
        Cancel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 255)));
        Cancel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cancel1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(282, Short.MAX_VALUE)
                .addComponent(Cancel, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Cancel1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ClearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cancel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ClearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Cancel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SaveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBtnActionPerformed
       
       
       try
        {
          String sql="";   

            
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/harrisdb","root","");
            
            Statement st=con.createStatement();
             
            if(FemalerdioBtn.isSelected()){
             sql=("insert into Teachers values('"+Integer.parseInt(IDTxtFild.getText())+ "' ,' " +NameTxtFild.getText()+ "' ,' " +EmailTxtFild.getText()+ "' ,' " +ContactTxtFild.getText()+ "' , '" +AdressTxtFild.getText()+ " ', '" +FemalerdioBtn.getText()+"','"+ComboBox.getSelectedItem()+"','"+salaryTxtFild.getText()+"')"  );
            maleRadioBtn.setSelected(false);
            }
            else if (maleRadioBtn.isSelected()){
                    sql=("insert into Teachers values('"+Integer.parseInt(IDTxtFild.getText())+ "' ,' " +NameTxtFild.getText()+ "' ,' " +EmailTxtFild.getText()+ "' ,' " +ContactTxtFild.getText()+ "' , '" +AdressTxtFild.getText()+ " ', '" +maleRadioBtn.getText()+"','"+ComboBox.getSelectedItem()+"','"+salaryTxtFild.getText()+"' )"  );
                FemalerdioBtn.setSelected(false);
            
            } 
           int n = st.executeUpdate(sql);
            
            if(n==1)
            {
          JOptionPane.showMessageDialog(rootPane, "Record Inserted");
            }
            else {
                JOptionPane.showMessageDialog(rootPane, "Record Not Inserted");
            }
        con.close();
        }
        catch(Exception e)
        {
            
           System.out.println(e.getMessage());
        } 
        
        
        
        
        
        
        
    }//GEN-LAST:event_SaveBtnActionPerformed

    private void Cancel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cancel1ActionPerformed
                    this.setVisible(false);
                    this.setLayout(null);
                    new Manipulation4Teachers().setVisible(true);
    }//GEN-LAST:event_Cancel1ActionPerformed

    private void CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelActionPerformed
                System.exit(0);
    }//GEN-LAST:event_CancelActionPerformed

    private void maleRadioBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maleRadioBtnActionPerformed
        if(this.maleRadioBtn.isSelected())
            this.FemalerdioBtn.setSelected(false);
    }//GEN-LAST:event_maleRadioBtnActionPerformed

    private void ClearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearBtnActionPerformed

        maleRadioBtn.setSelected(false);
       FemalerdioBtn.setSelected(false);
        IDTxtFild.setText(" ");
       NameTxtFild.setText(" ");
       ComboBox.setSelectedItem(false);
       EmailTxtFild.setText(" ");
       AdressTxtFild.setText(" ");
       ContactTxtFild.setText(" ");
       salaryTxtFild.setText(" ");
        
        
        
        
    }//GEN-LAST:event_ClearBtnActionPerformed

    private void FemalerdioBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FemalerdioBtnActionPerformed
        if(this.FemalerdioBtn.isSelected())
            this.maleRadioBtn.setSelected(false);
    }//GEN-LAST:event_FemalerdioBtnActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TeacherInfo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AdressLabel;
    private javax.swing.JTextField AdressTxtFild;
    private javax.swing.JButton Cancel;
    private javax.swing.JButton Cancel1;
    private javax.swing.JButton ClearBtn;
    private javax.swing.JComboBox<String> ComboBox;
    private javax.swing.JLabel ContactLable;
    private javax.swing.JTextField ContactTxtFild;
    private javax.swing.JLabel EmailLabel;
    private javax.swing.JTextField EmailTxtFild;
    private javax.swing.JRadioButton FemalerdioBtn;
    private javax.swing.JLabel IDLabel;
    private javax.swing.JTextField IDTxtFild;
    private javax.swing.JTextField NameTxtFild;
    private javax.swing.JButton SaveBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton maleRadioBtn;
    private javax.swing.JLabel namelabel;
    private javax.swing.JTextField salaryTxtFild;
    // End of variables declaration//GEN-END:variables
}
