
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import static javax.swing.text.html.parser.DTDConstants.SYSTEM;

public class InsertStudent extends javax.swing.JFrame {

    public InsertStudent(String Section) {
        initComponents();
        SectionTxtFild.setText(Section);
        
        if(Section.equals("A")){
        RoomIdTxtFild.setText("101");
        }
        else if(Section.equals("B")){
             RoomIdTxtFild.setText("102");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        totalfeeTxtFild = new javax.swing.JTextField();
        TotalFeesLabel = new javax.swing.JLabel();
        FeeStatusLbl1 = new javax.swing.JLabel();
        FeeStatusTxtFild1 = new javax.swing.JTextField();
        saveBtn4Fees = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        RoomIDlbl = new javax.swing.JLabel();
        RoomIdTxtFild = new javax.swing.JTextField();
        ContactTxtFild = new javax.swing.JTextField();
        ContactNoLabel = new javax.swing.JLabel();
        AddressLabel = new javax.swing.JLabel();
        AddressTxtFild = new javax.swing.JTextField();
        maleRdBtn = new javax.swing.JRadioButton();
        FemaleRdBtn = new javax.swing.JRadioButton();
        EmailtxtFild = new javax.swing.JTextField();
        EmailLabel = new javax.swing.JLabel();
        GenderLabel = new javax.swing.JLabel();
        SIDtxtFild = new javax.swing.JTextField();
        StudentIDLabel = new javax.swing.JLabel();
        StudentNameLabel = new javax.swing.JLabel();
        Classlabel = new javax.swing.JLabel();
        SectionLabel = new javax.swing.JLabel();
        SectionTxtFild = new javax.swing.JTextField();
        ClasstxtFild = new javax.swing.JTextField();
        StdentNametxtFild = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        CancelBtn = new javax.swing.JButton();
        SaveBtn = new javax.swing.JButton();
        ResetBtn = new javax.swing.JButton();
        BackBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 139, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Financial Status");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));

        totalfeeTxtFild.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalfeeTxtFildActionPerformed(evt);
            }
        });

        TotalFeesLabel.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        TotalFeesLabel.setForeground(new java.awt.Color(255, 255, 255));
        TotalFeesLabel.setText("Total Fees");

        FeeStatusLbl1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        FeeStatusLbl1.setForeground(new java.awt.Color(255, 255, 255));
        FeeStatusLbl1.setText("Fees Status");

        saveBtn4Fees.setBackground(new java.awt.Color(0, 153, 153));
        saveBtn4Fees.setForeground(new java.awt.Color(255, 255, 255));
        saveBtn4Fees.setText("save");
        saveBtn4Fees.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        saveBtn4Fees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtn4FeesActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Room Status");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));

        RoomIDlbl.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RoomIDlbl.setForeground(new java.awt.Color(255, 255, 255));
        RoomIDlbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        RoomIDlbl.setText("Room ID");

        ContactTxtFild.setFont(new java.awt.Font("Meiryo", 0, 11)); // NOI18N

        ContactNoLabel.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ContactNoLabel.setForeground(new java.awt.Color(255, 255, 255));
        ContactNoLabel.setText(" Contact No.");

        AddressLabel.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        AddressLabel.setForeground(new java.awt.Color(255, 255, 255));
        AddressLabel.setText(" Address");

        AddressTxtFild.setFont(new java.awt.Font("Meiryo", 0, 11)); // NOI18N

        maleRdBtn.setText("male");
        maleRdBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maleRdBtnActionPerformed(evt);
            }
        });

        FemaleRdBtn.setText("FeMale");
        FemaleRdBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FemaleRdBtnActionPerformed(evt);
            }
        });

        EmailtxtFild.setFont(new java.awt.Font("Meiryo", 0, 11)); // NOI18N

        EmailLabel.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        EmailLabel.setForeground(new java.awt.Color(255, 255, 255));
        EmailLabel.setText("Email");

        GenderLabel.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        GenderLabel.setForeground(new java.awt.Color(255, 255, 255));
        GenderLabel.setText("Gender");

        SIDtxtFild.setFont(new java.awt.Font("Meiryo", 0, 11)); // NOI18N

        StudentIDLabel.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        StudentIDLabel.setForeground(new java.awt.Color(255, 255, 255));
        StudentIDLabel.setText("ID");

        StudentNameLabel.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        StudentNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        StudentNameLabel.setText("Name");

        Classlabel.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        Classlabel.setForeground(new java.awt.Color(255, 255, 255));
        Classlabel.setText("Class");

        SectionLabel.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        SectionLabel.setForeground(new java.awt.Color(255, 255, 255));
        SectionLabel.setText("Section ");

        SectionTxtFild.setFont(new java.awt.Font("Meiryo", 0, 11)); // NOI18N

        ClasstxtFild.setFont(new java.awt.Font("Meiryo", 0, 11)); // NOI18N

        StdentNametxtFild.setFont(new java.awt.Font("Meiryo", 0, 11)); // NOI18N
        StdentNametxtFild.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StdentNametxtFildActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Student Information");
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));

        CancelBtn.setBackground(new java.awt.Color(0, 153, 153));
        CancelBtn.setForeground(new java.awt.Color(255, 255, 255));
        CancelBtn.setText("Cancel");
        CancelBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        CancelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelBtnActionPerformed(evt);
            }
        });

        SaveBtn.setBackground(new java.awt.Color(0, 153, 153));
        SaveBtn.setForeground(new java.awt.Color(255, 255, 255));
        SaveBtn.setText("Save");
        SaveBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SaveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBtnActionPerformed(evt);
            }
        });

        ResetBtn.setBackground(new java.awt.Color(0, 153, 153));
        ResetBtn.setForeground(new java.awt.Color(255, 255, 255));
        ResetBtn.setText("Clear");
        ResetBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        ResetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetBtnActionPerformed(evt);
            }
        });

        BackBtn.setBackground(new java.awt.Color(0, 153, 153));
        BackBtn.setForeground(new java.awt.Color(255, 255, 255));
        BackBtn.setText("Back");
        BackBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addComponent(BackBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(CancelBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ResetBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ResetBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE)
                    .addComponent(BackBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(CancelBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SaveBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(305, 305, 305)
                .addComponent(RoomIDlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RoomIdTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(239, 309, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(totalfeeTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TotalFeesLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(41, 41, 41)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(FeeStatusLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(FeeStatusTxtFild1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(66, 66, 66)
                                .addComponent(saveBtn4Fees, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(312, 312, 312))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(178, 178, 178)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(Classlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(ClasstxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(SectionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(SectionTxtFild))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(StudentIDLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(SIDtxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(StudentNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(StdentNametxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(76, 76, 76)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(EmailLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(EmailtxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(GenderLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(maleRdBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(FemaleRdBtn))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(AddressLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AddressTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(ContactNoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ContactTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StudentIDLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SIDtxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EmailLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EmailtxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StudentNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StdentNametxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(GenderLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(maleRdBtn)
                    .addComponent(FemaleRdBtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Classlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ClasstxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddressLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddressTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SectionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SectionTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ContactNoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ContactTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RoomIDlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RoomIdTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TotalFeesLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FeeStatusLbl1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FeeStatusTxtFild1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(saveBtn4Fees, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(totalfeeTxtFild, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(374, 374, 374)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 93, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void StdentNametxtFildActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StdentNametxtFildActionPerformed
         
    }//GEN-LAST:event_StdentNametxtFildActionPerformed

    private void CancelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelBtnActionPerformed
        System.exit(0);       // Cancel this interface          
    }//GEN-LAST:event_CancelBtnActionPerformed

    private void BackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtnActionPerformed
        this.setVisible(false);
        this.setLayout(null);
        new Student_data().setVisible(true);       //Back to main Manu
    }//GEN-LAST:event_BackBtnActionPerformed
//String sqll="select student_id from class_A where "+ Integer.parseInt(SIDtxtFild.getText()) +" in(  select student_id from class_A);";
//            ResultSet rs=st.executeQuery(sqll);
//            if(sqll.equals(true)){
//                JOptionPane.showMessageDialog(null, "Student ID already exist");
//                System.out.println("here coming??");
//            }
    
    
    
    private void SaveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBtnActionPerformed
       // String sql;
       try
        {
            String sql="" ;

            
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/harrisdb","root","");
            System.out.println("connection Established");
            Statement st=con.createStatement();
            System.out.println("11111");
            //String sql="select student_id from Class_A";
            
            if(SectionTxtFild.getText().equalsIgnoreCase("A"))
                
            {
                
             if(FemaleRdBtn.isSelected()) 
            {
                 
            sql=("insert into Class_A values('"+Integer.parseInt(SIDtxtFild.getText())+ "' ,' " +StdentNametxtFild.getText()+ "' ,' " +ClasstxtFild.getText()+ "' ,' " +SectionTxtFild.getText()+ "' , '" +EmailtxtFild.getText()+ " ', '" +FemaleRdBtn.getText()+ "' , '" +AddressTxtFild.getText()+ "' , '" +ContactTxtFild.getText()+"' )"  );
            maleRdBtn.setSelected(false);
            }
            else{
                     sql=("insert into Class_A values('"+Integer.parseInt(SIDtxtFild.getText())+ "' ,' " +StdentNametxtFild.getText()+ "' ,' " +ClasstxtFild.getText()+ "' ,' " +SectionTxtFild.getText()+ "' , '" +EmailtxtFild.getText()+ " ', '" +maleRdBtn.getText()+ "' , '" +AddressTxtFild.getText()+ "' , '" +ContactTxtFild.getText()+" ' )"  );
                FemaleRdBtn.setSelected(false);
                 
            }
            
           
            }
            else if(SectionTxtFild.getText().equalsIgnoreCase("B")){
              sql=("insert into Class_B values('"+Integer.parseInt(SIDtxtFild.getText())+ "' ,' " +StdentNametxtFild.getText()+ "' ,' " +ClasstxtFild.getText()+ "' ,' " +SectionTxtFild.getText()+ "' , '" +EmailtxtFild.getText()+ " ', '" +FemaleRdBtn.getText()+ "' , '" +AddressTxtFild.getText()+ "' , '" +ContactTxtFild.getText()+"')"  );
            maleRdBtn.setSelected(false);
            }
            else{
                     sql=("insert into Class_B values('"+Integer.parseInt(SIDtxtFild.getText())+ "' ,' " +StdentNametxtFild.getText()+ "' ,' " +ClasstxtFild.getText()+ "' ,' " +SectionTxtFild.getText()+ "' , '" +EmailtxtFild.getText()+ " ', '" +maleRdBtn.getText()+ "' , '" +AddressTxtFild.getText()+ "' , '" +ContactTxtFild.getText()+" ')"  );
                FemaleRdBtn.setSelected(false);
            }
        
            int n = st.executeUpdate(sql);
             if(n==1)
                
            {
          JOptionPane.showMessageDialog(rootPane, "Record Inserted");
            }
            else {
                JOptionPane.showMessageDialog(rootPane, "Record Not Inserted");
            }
             con.close();
            }catch(Exception e)
        {
            
           System.out.println(e.getMessage());
          
         
                JOptionPane.showMessageDialog(null, "ID already exists");
        } 
        
    }//GEN-LAST:event_SaveBtnActionPerformed

    private void ResetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetBtnActionPerformed
       maleRdBtn.setSelected(false);
       FemaleRdBtn.setSelected(false);
        SIDtxtFild.setText(" ");
       StdentNametxtFild.setText(" ");
       ClasstxtFild.setText(" ");
       SectionTxtFild.setText(" ");
       EmailtxtFild.setText(" ");
       AddressTxtFild.setText(" ");
       ContactTxtFild.setText(" ");
    }//GEN-LAST:event_ResetBtnActionPerformed

    private void maleRdBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maleRdBtnActionPerformed
            if(maleRdBtn.isSelected())
                 FemaleRdBtn.setSelected(false);
        // TODO add your handling code here:
    }//GEN-LAST:event_maleRdBtnActionPerformed

    private void FemaleRdBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FemaleRdBtnActionPerformed
            if(FemaleRdBtn.isSelected())
                maleRdBtn.setSelected(false);
        // TODO add your handling code here:
    }//GEN-LAST:event_FemaleRdBtnActionPerformed

    private void saveBtn4FeesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtn4FeesActionPerformed
         
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/harrisdb","root","");
            
            Statement st=con.createStatement();
            String sql="insert into Fees values('"+Integer.parseInt(SIDtxtFild.getText())+"','"+totalfeeTxtFild.getText()+"','"+FeeStatusTxtFild1.getText()+"')";
           st.executeUpdate(sql);
            
            con.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
            
        
        
        
        
        
    }//GEN-LAST:event_saveBtn4FeesActionPerformed

    private void totalfeeTxtFildActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalfeeTxtFildActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalfeeTxtFildActionPerformed

    public static void main(String args[]) {


        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InsertStudent("").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AddressLabel;
    private javax.swing.JTextField AddressTxtFild;
    private javax.swing.JButton BackBtn;
    private javax.swing.JButton CancelBtn;
    private javax.swing.JLabel Classlabel;
    private javax.swing.JTextField ClasstxtFild;
    private javax.swing.JLabel ContactNoLabel;
    private javax.swing.JTextField ContactTxtFild;
    private javax.swing.JLabel EmailLabel;
    private javax.swing.JTextField EmailtxtFild;
    private javax.swing.JLabel FeeStatusLbl1;
    private javax.swing.JTextField FeeStatusTxtFild1;
    private javax.swing.JRadioButton FemaleRdBtn;
    private javax.swing.JLabel GenderLabel;
    private javax.swing.JButton ResetBtn;
    private javax.swing.JLabel RoomIDlbl;
    private javax.swing.JTextField RoomIdTxtFild;
    private javax.swing.JTextField SIDtxtFild;
    private javax.swing.JButton SaveBtn;
    private javax.swing.JLabel SectionLabel;
    private javax.swing.JTextField SectionTxtFild;
    private javax.swing.JTextField StdentNametxtFild;
    private javax.swing.JLabel StudentIDLabel;
    private javax.swing.JLabel StudentNameLabel;
    private javax.swing.JLabel TotalFeesLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JRadioButton maleRdBtn;
    private javax.swing.JButton saveBtn4Fees;
    private javax.swing.JTextField totalfeeTxtFild;
    // End of variables declaration//GEN-END:variables
}
