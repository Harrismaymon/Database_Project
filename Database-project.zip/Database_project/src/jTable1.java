 
class jTable1 {
    
}
