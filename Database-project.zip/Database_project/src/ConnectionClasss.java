 import java.sql.*;  
import java.util.logging.Level;
import java.util.logging.Logger;


public class ConnectionClasss {
   public static void main(String args[]){
        try{
           Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/harrisdb","root","1234");
            Statement st =con.createStatement();
         

        }catch(Exception e)
         {
             System.out.println(e.getMessage());
            }
   
}
//            ResultSet sr = st.executeQuery(sql);
//           while(sr.next())
//            {
//                System.out.println(sr.getString("first_name"));
//            }
//             con.close();
//             
        
 
    


}