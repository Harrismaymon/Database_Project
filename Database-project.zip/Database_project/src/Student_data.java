import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class Student_data extends javax.swing.JFrame {
public void fetch(){
    try {
         Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/harrisdb","root","");
            Statement st =con.createStatement();
        String sql="Select * from students";
        
        con.close();
    }catch(Exception e){
        JOptionPane.showMessageDialog(rootPane, e);
    }
}
    
    String name;
    public Student_data() {
        initComponents();
        //fetch();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SearchStudentBtn = new javax.swing.JButton();
        BackBtn = new javax.swing.JButton();
        AddStudentBtn = new javax.swing.JButton();
        DeleteStudentBtn = new javax.swing.JButton();
        UpdateStudentBtn = new javax.swing.JButton();
        StudentRecordBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        EligableStudents = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        ComboBox = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        SearchStudentBtn.setBackground(new java.awt.Color(204, 204, 204));
        SearchStudentBtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        SearchStudentBtn.setText("Search Student");
        SearchStudentBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SearchStudentBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchStudentBtnActionPerformed(evt);
            }
        });

        BackBtn.setBackground(new java.awt.Color(204, 204, 204));
        BackBtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        BackBtn.setText("Back");
        BackBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtnActionPerformed(evt);
            }
        });

        AddStudentBtn.setBackground(new java.awt.Color(204, 204, 204));
        AddStudentBtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        AddStudentBtn.setText("Add Student");
        AddStudentBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        AddStudentBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddStudentBtnActionPerformed(evt);
            }
        });

        DeleteStudentBtn.setBackground(new java.awt.Color(204, 204, 204));
        DeleteStudentBtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        DeleteStudentBtn.setText("Delete Student");
        DeleteStudentBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        DeleteStudentBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteStudentBtnActionPerformed(evt);
            }
        });

        UpdateStudentBtn.setBackground(new java.awt.Color(204, 204, 204));
        UpdateStudentBtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        UpdateStudentBtn.setText("Update Student");
        UpdateStudentBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        UpdateStudentBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateStudentBtnActionPerformed(evt);
            }
        });

        StudentRecordBtn.setBackground(new java.awt.Color(204, 204, 204));
        StudentRecordBtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        StudentRecordBtn.setText("Students Record");
        StudentRecordBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        StudentRecordBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentRecordBtnActionPerformed(evt);
            }
        });

        jTable1.setBorder(new javax.swing.border.MatteBorder(null));
        jTable1.setFont(new java.awt.Font("Verdana", 2, 11)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Class", "Section", "Email", "Gender", "Adress", "Contact"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
            jTable1.getColumnModel().getColumn(6).setResizable(false);
            jTable1.getColumnModel().getColumn(7).setResizable(false);
        }

        EligableStudents.setBackground(new java.awt.Color(204, 204, 204));
        EligableStudents.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        EligableStudents.setText("Eligble Students");
        EligableStudents.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        EligableStudents.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EligableStudentsActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(102, 102, 255));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Students Record");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 811, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        ComboBox.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Section", "A", "B" }));
        ComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SearchStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DeleteStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UpdateStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StudentRecordBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BackBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EligableStudents, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 659, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AddStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SearchStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(DeleteStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(UpdateStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(StudentRecordBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BackBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(EligableStudents, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(59, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddStudentBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddStudentBtnActionPerformed
        String cmd = evt.getActionCommand();
           this.setVisible(false);
           this.setLayout(null);
           
           new InsertStudent(ComboBox.getSelectedItem().toString()).setVisible(true);
    }//GEN-LAST:event_AddStudentBtnActionPerformed

    private void BackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtnActionPerformed
        this.setVisible(false);
        this.setLayout(null);
        new Main_menu().setVisible(true);
    }//GEN-LAST:event_BackBtnActionPerformed

    private void SearchStudentBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchStudentBtnActionPerformed



            String Rcd =JOptionPane.showInputDialog("Enter your required value" );

        try{   
        Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/harrisdb","root","");
            Statement st=con.createStatement();
          if(ComboBox.getSelectedItem().equals("A")){
            String sql="select * from Class_A  where student_id="+Rcd;
            ResultSet rs= st.executeQuery(sql);
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          }
          // end if
         else if(ComboBox.getSelectedItem().equals("B")){
            String sql="select * from Class_B  where student_id="+Rcd;
            ResultSet rs= st.executeQuery(sql);
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          
         }
          con.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_SearchStudentBtnActionPerformed

    
    private void DeleteStudentBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteStudentBtnActionPerformed
            String rcd=JOptionPane.showInputDialog("Insert the student ID");
         try
        {

            Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/harrisdb","root","");
            Statement st=con.createStatement();
            System.out.println("stat created");
             String sq="delete  from Fees where student_id = " +rcd;
            st.executeUpdate(sq);
            
            
            if(ComboBox.getSelectedItem().equals("A"))
            {
            String sql="delete from Class_A where student_id="+rcd;
            st.executeUpdate(sql);
            }
            else if(ComboBox.getSelectedItem().equals("B"))
            {
            String sql="delete from Class_B where student_id="+rcd;
            st.executeUpdate(sql);
                
            }
            
            
            JOptionPane.showMessageDialog(rootPane, "Record deleted");

            con.close();
            
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        
    }//GEN-LAST:event_DeleteStudentBtnActionPerformed

    private void UpdateStudentBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateStudentBtnActionPerformed
        this.setVisible(false);
        this.setLayout(null);
        new Update_Class().setVisible(true);
    }//GEN-LAST:event_UpdateStudentBtnActionPerformed

    private void StudentRecordBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentRecordBtnActionPerformed
                
        try{   
        Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/harrisdb","root","");
            Statement st=con.createStatement();
          
            if(ComboBox.getSelectedItem().equals("A")){
            String sql="select * from Class_A order by student_id asc";
            ResultSet rs= st.executeQuery(sql);
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          }
          else if(ComboBox.getSelectedItem().equals("B")){
               String sql="select * from Class_B order by student_id asc";
            ResultSet rs= st.executeQuery(sql);
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
              
              
              }
            con.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_StudentRecordBtnActionPerformed

    private void EligableStudentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EligableStudentsActionPerformed
            try{
          Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/harrisdb","root",""); 
            Statement st=con.createStatement();
           if(ComboBox.getSelectedItem().equals("A"))
           {
            String sql="select s.student_id, s.first_name ,s.class, f.fee_status from Class_A s, fees f where s.student_id=f.student_id and f.fee_status='yes' order by student_id asc";
            ResultSet rs=st.executeQuery(sql);
             jTable1.setModel(DbUtils.resultSetToTableModel(rs));
           } 
           if(ComboBox.getSelectedItem().equals("B"))
           {
            String sql="select s.student_id, s.first_name ,s.class, f.fee_status from Class_B s, fees f where s.student_id=f.student_id and f.fee_status='yes' order by student_id asc";
            ResultSet rs=st.executeQuery(sql);
             jTable1.setModel(DbUtils.resultSetToTableModel(rs));
           }
            con.close();
            }catch(Exception e){
                System.out.println(e.getMessage());
            } 
        
        
        
    }//GEN-LAST:event_EligableStudentsActionPerformed

    private void ComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxActionPerformed
          
       
        
        
        
        
    }//GEN-LAST:event_ComboBoxActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Student_data().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddStudentBtn;
    private javax.swing.JButton BackBtn;
    private javax.swing.JComboBox<String> ComboBox;
    private javax.swing.JButton DeleteStudentBtn;
    private javax.swing.JButton EligableStudents;
    private javax.swing.JButton SearchStudentBtn;
    private javax.swing.JButton StudentRecordBtn;
    private javax.swing.JButton UpdateStudentBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
